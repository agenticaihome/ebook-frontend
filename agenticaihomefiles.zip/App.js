import SalesPage from './SalesPage';

function App() {
  return <SalesPage />;
}

export default App;
