# Payment Flow Diagram

## Complete Transaction Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER (Browser)                          │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 1. Enters email & clicks "Purchase"
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SALES PAGE (React)                           │
│  • Displays wallet address                                      │
│  • Shows payment amount (27.27 ERG)                            │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 2. User sends ERG from wallet
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    ERGO BLOCKCHAIN                              │
│  • User sends 27.27 ERG                                         │
│  • To: 9gxmJ4attdDx1NnZL7tWkN2U9iwZbPWWSEcfcPHbJXc7xsLq6QK      │
│  • Transaction confirmed (~2 minutes)                           │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 3. User copies transaction ID
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SALES PAGE (React)                           │
│  • User pastes transaction ID                                   │
│  • Clicks "Verify Payment"                                      │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 4. POST /api/verify-payment
                         │    { transactionId, email }
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                 BACKEND SERVER (Node.js)                        │
│  Step 1: Receive request                                        │
│  Step 2: Check if transaction already processed                 │
│  Step 3: Query Ergo blockchain via API                          │
│  Step 4: Verify:                                                │
│          - Correct wallet address?                              │
│          - Correct amount (27.27 ERG)?                          │
│          - Enough confirmations?                                │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 5. Query Ergo Explorer API
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│              ERGO EXPLORER API                                  │
│  GET /api/v1/transactions/{txId}                                │
│  Returns:                                                       │
│  • Transaction details                                          │
│  • Outputs (amount, address)                                    │
│  • Confirmations                                                │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 6. Transaction data returned
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                 BACKEND SERVER (Node.js)                        │
│  Step 5: Validation passed ✓                                    │
│  Step 6: Send ebook files via email                             │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 7. Send email with attachments
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                 EMAIL SERVICE (Gmail/SendGrid)                  │
│  To: user@example.com                                           │
│  Subject: Your Ebook Parts 2-5                                  │
│  Attachments: part2.pdf, part3.pdf, part4.pdf, part5.pdf       │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 8. Email sent successfully
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                 BACKEND SERVER (Node.js)                        │
│  Step 7: Mark transaction as processed                          │
│  Step 8: Return success response                                │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 9. { success: true, message: "..." }
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SALES PAGE (React)                           │
│  • Show success message                                         │
│  • Display confirmation                                         │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ 10. User receives confirmation
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                         USER (Browser)                          │
│  • Sees "Payment Confirmed! 🎉"                                 │
│  • Checks email for ebook files                                 │
│  • Downloads and enjoys the book!                               │
└─────────────────────────────────────────────────────────────────┘
```

## Error Handling Scenarios

### ❌ Transaction Not Found
```
User Input → Backend → Ergo API → Returns 404
                    ↓
         Error: "Transaction not found"
                    ↓
         User notified to check TX ID
```

### ❌ Wrong Amount
```
User Input → Backend → Ergo API → Returns TX data
                    ↓
         Verify amount: 20 ERG ≠ 27.27 ERG
                    ↓
         Error: "Incorrect amount"
                    ↓
         User notified to send correct amount
```

### ❌ Already Processed
```
User Input → Backend → Check processed list
                    ↓
         TX ID found in database
                    ↓
         Error: "Already processed"
                    ↓
         User notified (prevent double-delivery)
```

### ❌ Email Failed
```
Backend verified TX → Send email → Email service fails
                    ↓
         Error logged, but payment marked valid
                    ↓
         Error: "Payment verified, email failed"
                    ↓
         User contacts support for manual delivery
```

## Security Checkpoints

1. ✓ Validate transaction ID format
2. ✓ Check transaction on blockchain (not user input)
3. ✓ Verify exact amount matches
4. ✓ Verify payment sent to correct address
5. ✓ Require minimum confirmations
6. ✓ Prevent duplicate processing
7. ✓ Rate limit API requests
8. ✓ Secure email credentials

## Files & Their Roles

- **SalesPage.jsx**: Frontend React component
- **backend-server.js**: Payment verification server
- **package.json**: Node.js dependencies
- **.env**: Configuration secrets (email, etc.)
- **ebooks/**: PDF files to deliver

## API Endpoints

### POST /api/verify-payment
Verifies blockchain transaction and sends ebook

**Request:**
```json
{
  "transactionId": "abc123...",
  "email": "user@example.com"
}
```

**Success Response:**
```json
{
  "success": true,
  "message": "Payment verified and ebook sent!",
  "transaction": {
    "id": "abc123...",
    "amount": 27.27,
    "confirmations": 2
  }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Transaction not found"
}
```

### GET /api/health
Health check endpoint

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2025-11-17T..."
}
```
