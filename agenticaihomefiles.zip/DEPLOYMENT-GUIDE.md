# Complete Deployment Guide for Beginners

## Step-by-Step: Get Your Site Live in 2 Hours

### Part 1: Setup Your Computer (10 minutes)

1. **Install Node.js**
   - Go to nodejs.org
   - Download LTS version
   - Install it
   - Verify: Open terminal and type `node --version`

2. **Install Git**
   - Go to git-scm.com
   - Download and install
   - Verify: `git --version`

3. **Create GitHub Account**
   - Go to github.com
   - Sign up (free)

### Part 2: Prepare Your Files (20 minutes)

1. **Create Project Folders**
```bash
mkdir ebook-sales
cd ebook-sales

# Create backend folder
mkdir backend
cd backend

# Copy these files here:
# - backend-server.js
# - package.json
# - .env.example

# Create ebooks folder
mkdir ebooks

# Add your PDF files to ebooks folder:
# - part2.pdf
# - part3.pdf
# - part4.pdf
# - part5.pdf
```

2. **Setup Environment Variables**
```bash
# Copy .env.example to .env
cp .env.example .env

# Edit .env file:
# EMAIL_USER=youremail@gmail.com
# EMAIL_PASSWORD=your-app-password
```

3. **Get Gmail App Password**
   - Go to myaccount.google.com/security
   - Enable 2-Step Verification (if not enabled)
   - Go to myaccount.google.com/apppasswords
   - Select "Mail" and your device
   - Copy the 16-character password
   - Paste it in .env as EMAIL_PASSWORD

4. **Test Backend Locally**
```bash
# Install dependencies
npm install

# Start server
npm start

# You should see:
# "Server running on port 3001"

# Test it:
# Open browser: http://localhost:3001/api/health
# Should show: {"status":"ok","timestamp":"..."}
```

### Part 3: Deploy Backend to Railway (15 minutes)

1. **Sign Up for Railway**
   - Go to railway.app
   - Click "Login" → "Login with GitHub"
   - Authorize Railway

2. **Create New Project**
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Connect your GitHub account
   - Select your backend repository

3. **Configure Backend**
   - Railway will auto-detect Node.js
   - Click on your service
   - Go to "Variables" tab
   - Add these variables:
     * EMAIL_USER = your-email@gmail.com
     * EMAIL_PASSWORD = your-app-password
     * PORT = 3001

4. **Get Your Backend URL**
   - Go to "Settings" tab
   - Under "Networking" → "Generate Domain"
   - Copy URL (e.g., backend-production-abc123.railway.app)
   - Save this - you'll need it!

5. **Test Your Deployed Backend**
   - Open browser
   - Go to: https://your-backend.railway.app/api/health
   - Should show: {"status":"ok"}
   - ✅ Backend is live!

### Part 4: Deploy Frontend to Vercel (15 minutes)

1. **Sign Up for Vercel**
   - Go to vercel.com
   - Click "Sign Up"
   - Choose "Continue with GitHub"

2. **Update Frontend Code**
   - Open SalesPage.jsx
   - Find this line:
     ```javascript
     const response = await fetch('http://localhost:3001/api/verify-payment', {
     ```
   - Change to:
     ```javascript
     const response = await fetch('https://YOUR-BACKEND.railway.app/api/verify-payment', {
     ```
   - Replace YOUR-BACKEND with your actual Railway URL

3. **Deploy to Vercel**
   - In Vercel dashboard, click "Add New Project"
   - Import your frontend repository
   - Framework Preset: React
   - Click "Deploy"
   - Wait 2-3 minutes

4. **Get Your Website URL**
   - After deployment, you'll see your URL
   - Example: your-ebook-site.vercel.app
   - ✅ Website is live!

### Part 5: Test Complete Flow (20 minutes)

1. **Visit Your Website**
   - Open: your-ebook-site.vercel.app
   - Check all pages load

2. **Do Test Purchase**
   - Enter your email
   - Click "Purchase Parts 2-5"
   - Note the wallet address and amount

3. **Send Test Payment**
   - Open Nautilus wallet
   - Send EXACTLY 27.27 ERG to the address shown
   - Wait for transaction to confirm (~2 minutes)
   - Copy transaction ID

4. **Submit Transaction**
   - Paste transaction ID on your site
   - Click "Verify Payment"
   - Wait 10-30 seconds

5. **Check Email**
   - Check your inbox
   - Should see email with subject "Your Ebook Parts 2-5"
   - Verify PDFs are attached
   - ✅ Complete flow works!

### Part 6: Custom Domain (Optional - 30 minutes)

1. **Buy Domain**
   - Go to namecheap.com or godaddy.com
   - Search for your desired domain
   - Purchase (~$10-15/year)

2. **Connect to Vercel**
   - In Vercel dashboard
   - Go to your project → Settings → Domains
   - Click "Add Domain"
   - Enter your domain (e.g., agenticaihome.com)
   - Follow DNS instructions
   - Wait 1-48 hours for DNS propagation

### Part 7: Add Custom Domain to Backend (Optional)

1. **In Railway Dashboard**
   - Go to your backend service
   - Settings → Networking → Custom Domain
   - Add: api.yourdomain.com
   - Update DNS records as shown

2. **Update Frontend**
   - Change API URL to: https://api.yourdomain.com
   - Redeploy frontend

## 🎉 You're Live!

Your complete workflow:
```
Customer visits: yourdomain.com
           ↓
Sends ERG payment
           ↓
Submits transaction ID
           ↓
Backend verifies on blockchain
           ↓
Email sent with ebooks
           ↓
Customer downloads & reads!
```

## 📊 Monitor Your Sales

Railway Dashboard:
- View logs
- Check requests
- Monitor errors

Gmail:
- Track sent emails
- See delivery status

Ergo Explorer:
- Check incoming payments
- View transaction history
- Monitor your wallet: https://explorer.ergoplatform.com/

## 🔧 Troubleshooting

### "Cannot connect to backend"
→ Check Railway logs for errors
→ Verify environment variables are set
→ Check API URL in frontend code

### "Email not sending"
→ Verify Gmail app password is correct
→ Check Railway logs for email errors
→ Try SendGrid instead of Gmail

### "Transaction not found"
→ Wait 2-3 minutes for blockchain confirmation
→ Verify transaction ID is copied correctly
→ Check transaction on Ergo Explorer

### "CORS error"
→ Add your frontend domain to CORS config in backend
→ Update backend-server.js:
```javascript
app.use(cors({
  origin: 'https://your-site.vercel.app'
}));
```

## 💡 Next Steps

Once everything works:

1. **Add Analytics**
   - Google Analytics
   - Track conversions
   - Monitor traffic

2. **Add Database**
   - Track all sales
   - Generate reports
   - Customer records

3. **Marketing**
   - Share on Twitter/X
   - Post in Ergo community
   - Write blog posts

4. **Improve UX**
   - Add loading animations
   - Better error messages
   - Customer support chat

## 🎓 Learning Resources

- Railway docs: docs.railway.app
- Vercel docs: vercel.com/docs
- Ergo docs: docs.ergoplatform.com
- Node.js: nodejs.org/en/docs

## 📞 Get Help

If stuck:
1. Check Railway/Vercel logs
2. Test each component individually
3. Ask in Ergo Discord/Telegram
4. Review error messages carefully

---

**Remember:** Start simple, test thoroughly, then scale up!
