# 🪙 Complete Guide: How to Buy ERG (Ergo)

## Quick Overview

You need **27.27 ERG** to purchase the ebook (about $15 USD).
We recommend buying **36 ERG** (~$20) to have some extra.

---

## 🇺🇸 METHOD 1: US RESIDENTS - Nautilus + Banxa (EASIEST!)

### ⏱️ Time: 15 minutes | 💰 Fees: 3-5% | 🆔 KYC: Yes

**Best for:** US residents who want the fastest, easiest way

### Step-by-Step:

```
1. Install Nautilus Wallet
   └─ Go to: https://nautilus-wallet.io
   └─ Click "Install for Chrome"
   └─ Add the extension to your browser

2. Create Your Wallet
   └─ Click the Nautilus icon in browser
   └─ Click "Create Wallet"
   └─ Write down your 15-word seed phrase (CRITICAL!)
   └─ Set a password
   └─ Click "Create"

3. Click "Buy ERG" in Nautilus
   └─ Look for the "Buy" or "Buy ERG" button
   └─ Select "Banxa" as payment method

4. Purchase with Credit/Debit Card
   └─ Enter amount: $20 USD
   └─ Should get: ~36 ERG
   └─ Enter card details
   └─ Complete ID verification (photo of ID)
   └─ Confirm purchase

5. Wait for ERG to arrive
   └─ Takes 5-15 minutes
   └─ ERG appears automatically in Nautilus
   └─ You're ready to buy the book!
```

### 💡 Banxa Tips:
- First purchase requires ID verification (one time only)
- Use a credit card, not debit, for better fraud protection
- Total cost: ~$20.60 - $21.00 after Banxa fees
- Keep your seed phrase safe - it's your backup!

### ✅ Pros:
- Fastest method for US users
- No exchange account needed
- ERG goes directly to your wallet
- Simple one-click process

### ⚠️ Cons:
- Higher fees (3-5%)
- Requires ID verification
- Only available in US

---

## 🌍 METHOD 2: INTERNATIONAL - CoinEx (NO KYC!)

### ⏱️ Time: 20 minutes | 💰 Fees: 0.1% | 🆔 KYC: Not required

**Best for:** International users who want low fees and privacy

### Step-by-Step:

```
1. Install Nautilus Wallet First
   └─ Go to: https://nautilus-wallet.io
   └─ Install Chrome extension
   └─ Create wallet, save seed phrase
   └─ Copy your ERG receiving address:
      - Click "Receive" in Nautilus
      - Click "Copy Address"
      - Save it somewhere (you'll need it later)

2. Sign Up for CoinEx
   └─ Go to: https://www.coinex.com
   └─ Click "Sign Up"
   └─ Enter email and password
   └─ Verify email
   └─ No ID required! ✨

3. Deposit USDT (Tether Stablecoin)
   └─ Option A: Buy USDT with card on CoinEx
      - Go to "Buy Crypto"
      - Select USDT
      - Enter $20
      - Use credit card
   
   └─ Option B: Deposit from another wallet/exchange
      - Already have USDT? Send it to CoinEx
      - Go to "Assets" → "Deposit"
      - Select USDT
      - Choose network (recommend TRC20)
      - Copy deposit address
      - Send from your other wallet

4. Trade USDT for ERG
   └─ Click "Markets" or "Trade"
   └─ Search for "ERG/USDT"
   └─ Click on the trading pair
   └─ Click "Buy ERG"
   └─ Enter amount: 36 ERG (costs ~$20 USDT)
   └─ Click "Buy ERG" button
   └─ Confirm trade
   └─ Done! You now own 36 ERG

5. Withdraw ERG to Nautilus
   └─ Go to "Assets"
   └─ Find ERG in your list
   └─ Click "Withdraw"
   └─ Paste your Nautilus address
   └─ Enter amount: 36 ERG
   └─ Confirm withdrawal
   └─ Wait 5-10 minutes
   └─ Check Nautilus - ERG should appear!
```

### 💡 CoinEx Tips:
- No KYC required for daily withdrawals under $10,000
- Available in most countries (check if yours is supported)
- Very low trading fees (0.1%)
- Use TRC20 network for USDT - it's faster and cheaper

### ✅ Pros:
- No identity verification needed
- Very low fees
- Available worldwide (except restricted countries)
- Fast withdrawals

### ⚠️ Cons:
- Need to buy/have USDT first
- Requires understanding of trading pairs
- More steps than Banxa method

---

## 🌐 METHOD 3: WORLDWIDE - KuCoin

### ⏱️ Time: 30 minutes | 💰 Fees: 0.1% | 🆔 KYC: Basic verification required

**Best for:** Users who want a reputable, established exchange

### Step-by-Step:

```
1. Install Nautilus Wallet First
   └─ Go to: https://nautilus-wallet.io
   └─ Install extension, create wallet
   └─ Copy your ERG receiving address

2. Sign Up for KuCoin
   └─ Go to: https://www.kucoin.com
   └─ Click "Sign Up"
   └─ Enter email/phone and password
   └─ Verify your account

3. Complete Basic KYC (Required)
   └─ Click profile icon → "Verification"
   └─ Select "Individual Account"
   └─ Upload photo of ID (passport/driver's license)
   └─ Take selfie
   └─ Wait 5-10 minutes for approval

4. Buy Crypto or Deposit
   └─ Option A: Buy with credit card
      - Click "Buy Crypto"
      - Select USDT
      - Enter $20
      - Complete card payment
   
   └─ Option B: Deposit crypto from another wallet
      - Go to "Assets" → "Deposit"
      - Select USDT
      - Choose network (TRC20 recommended)
      - Send USDT to provided address

5. Trade USDT for ERG
   └─ Click "Trade" → "Spot Trading"
   └─ Search "ERG/USDT"
   └─ Click the pair
   └─ In buy section:
      - Enter amount: 36 ERG
      - Click "Buy ERG"
      - Confirm trade

6. Withdraw to Nautilus
   └─ Go to "Assets" → "Main Account"
   └─ Find ERG, click "Withdraw"
   └─ Paste your Nautilus address
   └─ Enter amount: 36 ERG
   └─ Complete 2FA if enabled
   └─ Confirm withdrawal
   └─ Wait 10-15 minutes
   └─ Check Nautilus!
```

### 💡 KuCoin Tips:
- Larger, more established exchange
- Good mobile app (iOS & Android)
- 24/7 customer support
- More secure with 2FA enabled

### ✅ Pros:
- Very reputable and reliable
- Great mobile app
- Good customer support
- Available in 200+ countries

### ⚠️ Cons:
- Requires ID verification
- Takes longer than other methods
- Slightly more complex interface

---

## 📊 QUICK COMPARISON TABLE

| Feature | Nautilus + Banxa 🇺🇸 | CoinEx 🌍 | KuCoin 🌐 |
|---------|---------------------|-----------|-----------|
| **Best For** | US residents | International | Worldwide |
| **Total Time** | 15 minutes | 20 minutes | 30 minutes |
| **KYC Required** | Yes | No* | Yes |
| **Fees** | 3-5% (~$1) | 0.1% (~$0.02) | 0.1% (~$0.02) |
| **Total Cost** | ~$21 | ~$20.02 | ~$20.02 |
| **Difficulty** | ⭐ Easy | ⭐⭐ Medium | ⭐⭐ Medium |
| **Countries** | US only | Most countries | 200+ countries |

*Under $10,000/day

---

## 🆘 TROUBLESHOOTING

### "I don't have USDT for CoinEx/KuCoin"

**Solution:** You have 3 options:
1. Buy USDT with credit card directly on the exchange
2. Buy USDT on Coinbase/Kraken and transfer to exchange
3. Use Nautilus + Banxa instead (direct ERG purchase)

### "My withdrawal is taking forever"

**Solution:** 
- Exchanges process withdrawals in batches
- CoinEx: Usually 5-10 minutes
- KuCoin: Usually 10-15 minutes
- Check the exchange's withdrawal history page
- Check Ergo Explorer: https://explorer.ergoplatform.com/

### "I sent ERG but it's not showing in Nautilus"

**Solution:**
1. Wait 2-3 minutes for blockchain confirmation
2. Check your Nautilus is on mainnet (not testnet)
3. Verify the address you sent to
4. Check transaction on Ergo Explorer
5. Refresh Nautilus wallet

### "Banxa declined my card"

**Solution:**
- Try a different card
- Call your bank - they may have blocked it
- Try smaller amount first ($10)
- Use debit card instead of credit card
- Try again in 24 hours

### "I accidentally bought too much ERG"

**Solution:**
- No problem! You can:
  1. Hold it (ERG is a good investment)
  2. Sell it back on the same exchange
  3. Use it to buy other things in the Ergo ecosystem
  4. Save it for future ebook purchases!

---

## 💡 PRO TIPS

### Security:
- ✅ **ALWAYS** write down your Nautilus seed phrase
- ✅ Never share your seed phrase with anyone
- ✅ Test withdrawals with small amounts first
- ✅ Double-check wallet addresses before sending
- ✅ Enable 2FA on exchanges for extra security

### Savings:
- 💰 CoinEx & KuCoin have much lower fees than Banxa
- 💰 Buy a bit extra now to avoid fees later
- 💰 Trading fees are lower than credit card fees

### Speed:
- ⚡ Banxa is fastest for US users (15 min)
- ⚡ CoinEx withdrawals are usually fastest (5-10 min)
- ⚡ Have USDT ready in advance to save time

---

## 🎯 RECOMMENDED PATH BY LOCATION

### 🇺🇸 United States
**Use:** Nautilus + Banxa
**Why:** Easiest, fastest, works best in US

### 🇪🇺 Europe
**Use:** CoinEx (no KYC) or KuCoin (with KYC)
**Why:** Both work well, CoinEx is faster

### 🇨🇦 Canada
**Use:** KuCoin
**Why:** Well-supported, good reputation

### 🇦🇺 Australia
**Use:** CoinEx or KuCoin
**Why:** Both available and reliable

### 🌏 Asia
**Use:** CoinEx (fastest) or KuCoin
**Why:** Very popular in Asia, fast transfers

### 🌍 Other Countries
**Use:** Try CoinEx first (no KYC)
**Why:** Available almost everywhere

---

## ✅ FINAL CHECKLIST

Before you buy the ebook, make sure you have:

- [ ] Nautilus wallet installed
- [ ] Seed phrase written down safely
- [ ] At least 27.27 ERG in your wallet (36 ERG recommended)
- [ ] Your wallet address copied
- [ ] Tested that you can see your ERG balance

**Ready to purchase?** Go back to the ebook site and complete your purchase!

---

## 📞 NEED MORE HELP?

- Nautilus Wallet Support: https://docs.nautilus-wallet.io
- Ergo Platform: https://ergoplatform.org
- CoinEx Support: help.coinex.com
- KuCoin Support: support.kucoin.plus

**Good luck getting your ERG, and enjoy the book!** 📚✨
