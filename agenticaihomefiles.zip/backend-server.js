// backend-server.js
// Simple Node.js/Express server for handling Ergo payment verification

require('dotenv').config(); // IMPORTANT: Load environment variables

const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());

// Configuration
const CONFIG = {
  WALLET_ADDRESS: "9gxmJ4attdDx1NnZL7tWkN2U9iwZbPWWSEcfcPHbJXc7xsLq6QK",
  EXPECTED_AMOUNT_ERG: 27.27, // Your book price in ERG
  REQUIRED_CONFIRMATIONS: 1, // Number of confirmations needed
  ERGO_EXPLORER_API: "https://api.ergoplatform.com/api/v1",
  PORT: process.env.PORT || 3001
};

// Validate environment variables on startup
if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
  console.error('ERROR: EMAIL_USER and EMAIL_PASSWORD must be set in .env file');
  process.exit(1);
}

// Email configuration (use your email service)
const emailTransporter = nodemailer.createTransport({
  service: 'gmail', // or 'sendgrid', 'mailgun', etc.
  auth: {
    user: process.env.EMAIL_USER, // Your email
    pass: process.env.EMAIL_PASSWORD // Your email password or app password
  }
});

// Verify email configuration on startup
emailTransporter.verify(function (error, success) {
  if (error) {
    console.error('Email configuration error:', error);
    console.error('Please check your EMAIL_USER and EMAIL_PASSWORD in .env file');
  } else {
    console.log('Email server is ready to send messages');
  }
});

// Verify transaction on Ergo blockchain
async function verifyErgoTransaction(txId, expectedAddress, expectedAmount) {
  try {
    console.log(`Verifying transaction: ${txId}`);
    
    // Get transaction details from Ergo Explorer API
    const response = await axios.get(
      `${CONFIG.ERGO_EXPLORER_API}/transactions/${txId}`,
      {
        timeout: 10000, // 10 second timeout
        headers: {
          'User-Agent': 'Ebook-Sales-Bot/1.0'
        }
      }
    );
    
    const transaction = response.data;
    
    // Check if transaction exists
    if (!transaction) {
      return { valid: false, error: 'Transaction not found' };
    }
    
    // Check confirmations
    if (transaction.numConfirmations < CONFIG.REQUIRED_CONFIRMATIONS) {
      return { 
        valid: false, 
        error: `Waiting for confirmations. Current: ${transaction.numConfirmations}, Required: ${CONFIG.REQUIRED_CONFIRMATIONS}` 
      };
    }
    
    // Find output to our wallet address
    const ourOutput = transaction.outputs.find(output => 
      output.address === expectedAddress
    );
    
    if (!ourOutput) {
      return { valid: false, error: 'Payment not sent to correct address' };
    }
    
    // Check amount (convert nanoERG to ERG)
    const receivedERG = ourOutput.value / 1000000000; // 1 ERG = 1,000,000,000 nanoERG
    
    // Allow small variance for transaction fees (0.1 ERG tolerance)
    if (Math.abs(receivedERG - expectedAmount) > 0.1) {
      return { 
        valid: false, 
        error: `Incorrect amount. Expected: ${expectedAmount} ERG, Received: ${receivedERG.toFixed(2)} ERG` 
      };
    }
    
    return { 
      valid: true, 
      amount: receivedERG,
      confirmations: transaction.numConfirmations,
      timestamp: transaction.timestamp
    };
    
  } catch (error) {
    console.error('Error verifying transaction:', error.message);
    
    // Handle specific errors
    if (error.response && error.response.status === 404) {
      return { 
        valid: false, 
        error: 'Transaction not found. Please check the transaction ID.' 
      };
    }
    
    if (error.code === 'ECONNABORTED') {
      return {
        valid: false,
        error: 'Request timeout. Please try again.'
      };
    }
    
    return { 
      valid: false, 
      error: `Failed to verify transaction: ${error.message}` 
    };
  }
}

// Send ebook files via email
async function sendEbookFiles(email, transactionId) {
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Your Ebook Parts 2-5 - Agentic AI at Home',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #7c3aed;">Thank you for your purchase! 🎉</h2>
          <p>Your payment has been confirmed on the Ergo blockchain.</p>
          <p><strong>Transaction ID:</strong> <code style="background: #f3f4f6; padding: 2px 6px; border-radius: 4px;">${transactionId}</code></p>
          
          <h3 style="color: #2563eb; margin-top: 30px;">Download Your Ebook Parts:</h3>
          
          <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin: 20px 0;">
            <p style="margin: 0 0 10px 0;">Your ebook files are attached to this email:</p>
            <ul style="margin: 10px 0;">
              <li>Part 2: Morning Routines & Kitchen Management</li>
              <li>Part 3: Household Operations & Productivity</li>
              <li>Part 4: Health & Mental Wellness</li>
              <li>Part 5: Multi-Agent Systems & The Future</li>
            </ul>
          </div>
          
          <div style="background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px; padding: 15px; margin: 20px 0;">
            <p style="margin: 0; color: #92400e;"><strong>💡 Tip:</strong> Save these files to your device or cloud storage for safekeeping!</p>
          </div>
          
          <p style="margin-top: 30px;">Thank you for supporting independent creators and decentralized commerce!</p>
          <p style="color: #6b7280;">- Dr. Maya Patel<br>Agentic AI at Home</p>
          
          <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">
          
          <p style="font-size: 12px; color: #9ca3af;">
            Questions? Reply to this email or contact agenticaiathome@gmail.com
          </p>
        </div>
      `,
      // Attach PDF files (uncomment and update paths when you have the files)
      attachments: [
        {
          filename: 'part2-morning-routines.pdf',
          path: './ebooks/part2.pdf' // Make sure this file exists!
        },
        {
          filename: 'part3-household-operations.pdf',
          path: './ebooks/part3.pdf'
        },
        {
          filename: 'part4-health-wellness.pdf',
          path: './ebooks/part4.pdf'
        },
        {
          filename: 'part5-future-systems.pdf',
          path: './ebooks/part5.pdf'
        }
      ]
    };
    
    const info = await emailTransporter.sendMail(mailOptions);
    console.log(`Ebook sent to ${email}. Message ID: ${info.messageId}`);
    return { success: true, messageId: info.messageId };
    
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error: error.message };
  }
}

// Store processed transactions (use a database in production)
const processedTransactions = new Set();

// API endpoint to verify payment and send ebook
app.post('/api/verify-payment', async (req, res) => {
  try {
    const { transactionId, email } = req.body;
    
    console.log(`Payment verification request: TX=${transactionId}, Email=${email}`);
    
    // Validation
    if (!transactionId || !email) {
      return res.status(400).json({ 
        success: false, 
        error: 'Transaction ID and email are required' 
      });
    }
    
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email address'
      });
    }
    
    // Check if transaction already processed
    if (processedTransactions.has(transactionId)) {
      return res.status(400).json({ 
        success: false, 
        error: 'This transaction has already been processed. Check your email for the ebook files.' 
      });
    }
    
    // Verify transaction on blockchain
    const verification = await verifyErgoTransaction(
      transactionId,
      CONFIG.WALLET_ADDRESS,
      CONFIG.EXPECTED_AMOUNT_ERG
    );
    
    if (!verification.valid) {
      console.log(`Verification failed: ${verification.error}`);
      return res.status(400).json({ 
        success: false, 
        error: verification.error 
      });
    }
    
    console.log(`Transaction verified: ${verification.amount} ERG, ${verification.confirmations} confirmations`);
    
    // Send ebook files
    const emailResult = await sendEbookFiles(email, transactionId);
    
    if (!emailResult.success) {
      console.error(`Failed to send email: ${emailResult.error}`);
      return res.status(500).json({ 
        success: false, 
        error: 'Payment verified but failed to send ebook. Please contact agenticaiathome@gmail.com with your transaction ID.' 
      });
    }
    
    // Mark transaction as processed
    processedTransactions.add(transactionId);
    console.log(`Transaction processed successfully: ${transactionId}`);
    
    // Success!
    res.json({ 
      success: true, 
      message: 'Payment verified and ebook sent! Check your email.',
      transaction: {
        id: transactionId,
        amount: verification.amount,
        confirmations: verification.confirmations
      }
    });
    
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Internal server error. Please try again or contact support.' 
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    walletAddress: CONFIG.WALLET_ADDRESS,
    bookPrice: `${CONFIG.EXPECTED_AMOUNT_ERG} ERG`
  });
});

// Test endpoint (remove in production)
app.get('/api/test-email', async (req, res) => {
  try {
    await emailTransporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_USER, // Send to yourself
      subject: 'Test Email from Ebook Backend',
      text: 'If you receive this, email is configured correctly!'
    });
    res.json({ success: true, message: 'Test email sent!' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Start server
app.listen(CONFIG.PORT, () => {
  console.log('='.repeat(60));
  console.log('🚀 Ebook Payment Server Started');
  console.log('='.repeat(60));
  console.log(`📡 Server running on port ${CONFIG.PORT}`);
  console.log(`💰 Watching for payments to: ${CONFIG.WALLET_ADDRESS}`);
  console.log(`💵 Expected amount: ${CONFIG.EXPECTED_AMOUNT_ERG} ERG`);
  console.log(`📧 Email configured: ${process.env.EMAIL_USER}`);
  console.log('='.repeat(60));
  console.log(`✅ Health check: http://localhost:${CONFIG.PORT}/api/health`);
  console.log(`✉️  Test email: http://localhost:${CONFIG.PORT}/api/test-email`);
  console.log('='.repeat(60));
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('\nSIGINT received, shutting down gracefully...');
  process.exit(0);
});
