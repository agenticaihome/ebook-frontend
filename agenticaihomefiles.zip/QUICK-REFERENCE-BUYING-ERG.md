# 🚀 QUICK REFERENCE: HOW TO BUY ERG FOR THE EBOOK

## For US Users (EASIEST - 15 minutes):

```
1. Go to nautilus-wallet.io → Install Chrome extension
2. Create wallet → Save seed phrase on paper
3. Click "Buy" in Nautilus (or visit ergo.banxa.com)
4. Buy $25 USD with credit/debit card
5. Wait 10-15 minutes → ERG appears in wallet
6. Done! Come back and buy ebook (27.27 ERG)

💰 Cost: ~$26 total
⏱️ Time: 15-20 minutes
```

## For International Users - Option 1: CoinEx (NO ID NEEDED):

```
1. Go to nautilus-wallet.io → Install & create wallet
2. Go to coinex.com → Sign up (email + password)
3. Buy/deposit $25 USDT (stablecoin)
4. Trade USDT for 45 ERG (search "ERG/USDT")
5. Withdraw ERG to your Nautilus address
6. Wait 10 minutes → Done!

💰 Cost: ~$25.10 total
⏱️ Time: 20-30 minutes
🎯 No KYC required!
```

## For International Users - Option 2: KuCoin (POPULAR):

```
1. Go to nautilus-wallet.io → Install & create wallet
2. Go to kucoin.com → Sign up
3. Upload ID photo (5-10 min verification)
4. Buy $25 USDT with card
5. Trade USDT for 45 ERG (search "ERG/USDT")
6. Withdraw ERG to Nautilus address
7. Done!

💰 Cost: ~$25.80 total
⏱️ Time: 30-40 minutes
📱 Has mobile app!
```

## After You Have ERG:

```
1. Come back to this ebook site
2. Click "Purchase Parts 2-5"
3. Enter your email
4. Send 27.27 ERG to the address shown
5. Copy transaction ID from Nautilus
6. Paste transaction ID on site
7. Check email for PDFs!
```

## ⚠️ GOLDEN RULES:

- ✅ Write seed phrase on paper (12 words)
- ❌ NEVER share seed phrase with anyone
- ❌ NEVER screenshot or save digitally
- ✅ Send test amount first (1 ERG) to verify address
- ✅ Double-check addresses before sending
- ✅ Buy 45 ERG (more than needed = safer)

## 🆘 NEED HELP?

- Ergo Discord/Telegram: ergoplatform.org
- Email support: support@agenticaihome.com
- Community is SUPER helpful with newcomers!

## 💡 PRO TIPS:

- **US users:** Banxa is by far easiest
- **International:** CoinEx if you don't want to upload ID
- **Already have crypto?** Send to exchange, trade for ERG
- **Don't worry:** Takes 15-40 min but you only do it once!
- **Extra ERG?** Keep it! It's actual money, could go up in value

---

**You got this!** 🎉 Thousands of people do this every day. It's easier than it looks!
