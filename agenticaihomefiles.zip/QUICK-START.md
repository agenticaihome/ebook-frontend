# 🚀 QUICK START GUIDE - Get Live in 1 Hour

## ⚡ Express Setup (Skip the reading, just do this)

### Step 1: Backend Setup (15 minutes)

```bash
# 1. Create backend folder
mkdir ebook-backend
cd ebook-backend

# 2. Copy these files into this folder:
#    - backend-server.js
#    - package.json
#    - .env.example

# 3. Install dependencies
npm install

# 4. Setup Gmail App Password
#    Go to: https://myaccount.google.com/apppasswords
#    Create password, copy it

# 5. Create .env file
cp .env.example .env

# 6. Edit .env (use your actual values):
EMAIL_USER=youremail@gmail.com
EMAIL_PASSWORD=your-16-char-app-password
PORT=3001

# 7. Create PDFs folder
mkdir ebooks
# Put your 4 PDF files here: part2.pdf, part3.pdf, part4.pdf, part5.pdf

# 8. Test locally
npm start

# 9. Test it works:
# Open browser: http://localhost:3001/api/health
# Should show: {"status":"ok",...}

# 10. Test email:
# Open browser: http://localhost:3001/api/test-email
# Check your email!
```

### Step 2: Deploy Backend to Railway (10 minutes)

```bash
# 1. Sign up: railway.app (use GitHub login)

# 2. Push code to GitHub first:
git init
git add .
echo "node_modules" > .gitignore
echo ".env" >> .gitignore
git commit -m "Initial commit"
gh repo create ebook-backend --private --source=. --push

# 3. In Railway dashboard:
#    - Click "New Project"
#    - Select "Deploy from GitHub"
#    - Choose your ebook-backend repo

# 4. Add environment variables in Railway:
#    Go to Variables tab, add:
#    EMAIL_USER=youremail@gmail.com
#    EMAIL_PASSWORD=your-app-password
#    PORT=3001

# 5. Get your URL:
#    Settings > Generate Domain
#    Copy: https://ebook-backend-production-xxxx.railway.app

# 6. Test deployed backend:
curl https://your-backend.railway.app/api/health
```

### Step 3: Frontend Setup (10 minutes)

```bash
# 1. Create frontend folder
mkdir ebook-frontend
cd ebook-frontend

# 2. Initialize React app
npx create-react-app .

# 3. Copy SalesPage.jsx to src/

# 4. Edit src/SalesPage.jsx line 40:
#    Change: http://localhost:3001
#    To: https://your-backend.railway.app

# 5. Install lucide-react
npm install lucide-react

# 6. Edit src/App.js:
import SalesPage from './SalesPage';

function App() {
  return <SalesPage />;
}

export default App;

# 7. Test locally:
npm start
# Opens browser at http://localhost:3000
```

### Step 4: Deploy Frontend to Vercel (10 minutes)

```bash
# 1. Sign up: vercel.com (use GitHub login)

# 2. Push to GitHub:
git init
git add .
git commit -m "Initial commit"
gh repo create ebook-frontend --public --source=. --push

# 3. In Vercel dashboard:
#    - Import Project
#    - Select ebook-frontend
#    - Click Deploy
#    - Wait 2 minutes

# 4. Get your URL:
#    Copy: https://ebook-frontend.vercel.app

# 5. Visit your site!
#    Test complete purchase flow
```

### Step 5: First Real Test (15 minutes)

```bash
# 1. Visit your site: https://ebook-frontend.vercel.app

# 2. Enter your email, click Purchase

# 3. Send 27.27 ERG to the wallet address shown
#    Use Nautilus or any Ergo wallet

# 4. Wait 2-3 minutes for confirmation

# 5. Copy transaction ID from wallet

# 6. Paste on your site, click Verify

# 7. Check your email for PDFs!

# 🎉 IF EMAIL ARRIVES - YOU'RE LIVE!
```

## 🎯 ONE-LINE CHECKLIST

```
□ npm install
□ Create .env with Gmail app password
□ Add 4 PDFs to ebooks folder
□ npm start (test locally)
□ Deploy to Railway
□ Update API URL in frontend
□ Deploy to Vercel
□ Send test payment
□ Check email
□ 🎉 LIVE!
```

## 🆘 FASTEST HELP

**Backend won't start:**
```bash
# Check .env exists and has EMAIL_USER and EMAIL_PASSWORD
cat .env
```

**Email won't send:**
```bash
# Test: http://localhost:3001/api/test-email
# Get Gmail app password: https://myaccount.google.com/apppasswords
```

**Frontend can't reach backend:**
```javascript
// Line 40 of SalesPage.jsx must have your Railway URL:
fetch('https://YOUR-BACKEND.railway.app/api/verify-payment', {
```

## 💰 COSTS

- Railway: FREE first $5/month, then ~$5/month
- Vercel: FREE forever
- Domain (optional): $12/year
- **Total: $0-5/month to start**

## 📞 SUPPORT SHORTCUTS

- Railway logs: `railway logs`
- Vercel logs: In dashboard > Deployments > Click deployment > Logs
- Ergo Explorer: https://explorer.ergoplatform.com/
- Test transaction on blockchain before submitting

## ✅ YOU'RE READY!

Everything is tested and working. Just follow the steps above and you'll be live in under an hour. Good luck! 🚀

**Next steps after launch:**
1. Share link in Ergo community
2. Add domain name
3. Monitor sales
4. Count money 💰
