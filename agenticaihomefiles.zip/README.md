# Ergo Ebook Payment System

Complete setup guide for your Ergo blockchain-powered ebook sales system.

## 📋 Overview

This system consists of:
- **Frontend (React)**: Sales page with payment interface
- **Backend (Node.js)**: Payment verification and ebook delivery

## 🚀 Backend Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment Variables

Create a `.env` file based on `.env.example`:

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
PORT=3001
```

**For Gmail:**
1. Enable 2-factor authentication on your Google account
2. Generate an "App Password": https://myaccount.google.com/apppasswords
3. Use this app password in `.env`

**Alternative Email Services:**
- SendGrid: More reliable for production
- Mailgun: Good for high volume
- AWS SES: Cost-effective for large scale

### 3. Add Your Ebook Files

Create an `ebooks` folder and add your PDF files:

```
ebooks/
  ├── part2.pdf
  ├── part3.pdf
  ├── part4.pdf
  └── part5.pdf
```

Or update the code to use download links instead of attachments.

### 4. Start the Server

Development mode (auto-restart on changes):
```bash
npm run dev
```

Production mode:
```bash
npm start
```

Server will run on `http://localhost:3001`

## 🎨 Frontend Setup

### 1. Update API Endpoint

In production, change the API endpoint in `SalesPage.jsx`:

```javascript
// Development
const API_URL = 'http://localhost:3001';

// Production
const API_URL = 'https://your-domain.com';
```

### 2. Deploy Frontend

Deploy your React app to:
- Vercel (recommended for React)
- Netlify
- GitHub Pages
- Your own hosting

## 🔐 Security Considerations

### For Production:

1. **Use HTTPS**: Always use HTTPS in production
2. **Environment Variables**: Never commit `.env` to git
3. **Rate Limiting**: Add rate limiting to prevent abuse:
   ```bash
   npm install express-rate-limit
   ```

4. **Database**: Store processed transactions in a database instead of memory:
   - PostgreSQL
   - MongoDB
   - SQLite

5. **API Key**: Add authentication to your API endpoints

6. **CORS**: Restrict CORS to your frontend domain only

## 🗄️ Database Integration (Recommended)

For production, track transactions in a database:

```javascript
// Example PostgreSQL schema
CREATE TABLE transactions (
  id SERIAL PRIMARY KEY,
  transaction_id VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) NOT NULL,
  amount DECIMAL(10, 2),
  status VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW()
);
```

## 🌐 Deployment Options

### Backend Deployment:

1. **Heroku** (Easy):
   ```bash
   heroku create your-app-name
   git push heroku main
   ```

2. **Railway** (Modern, easy):
   - Connect GitHub repo
   - Auto-deploys on push

3. **DigitalOcean / AWS / Google Cloud** (More control):
   - Deploy to VPS or container service
   - Use PM2 to keep server running

4. **Vercel Serverless Functions** (Alternative):
   - Convert Express routes to serverless functions
   - No need to manage server

### Frontend Deployment:

1. **Vercel** (Recommended):
   ```bash
   vercel
   ```

2. **Netlify**:
   ```bash
   netlify deploy
   ```

## 📊 Testing

### Test the Backend:

1. Start the server:
   ```bash
   npm start
   ```

2. Test health check:
   ```bash
   curl http://localhost:3001/api/health
   ```

3. Test payment verification (replace with real transaction ID):
   ```bash
   curl -X POST http://localhost:3001/api/verify-payment \
     -H "Content-Type: application/json" \
     -d '{"transactionId":"YOUR_TX_ID","email":"test@example.com"}'
   ```

### Test Payment Flow:

1. Send a test payment of 27.27 ERG to your wallet address
2. Copy the transaction ID from Nautilus wallet
3. Submit it through your frontend
4. Check your email for the ebook files

## 🔧 Troubleshooting

### "Transaction not found"
- Wait 1-2 minutes for blockchain confirmation
- Verify the transaction ID is correct
- Check Ergo Explorer: https://explorer.ergoplatform.com/

### "Failed to send email"
- Check email credentials in `.env`
- Verify Gmail app password is correct
- Check email service logs

### CORS errors
- Ensure frontend URL is allowed in CORS configuration
- Check browser console for specific CORS error

## 📈 Monitoring & Analytics

Consider adding:
- Transaction logging
- Email delivery tracking
- Error monitoring (e.g., Sentry)
- Sales analytics dashboard

## 💡 Enhancements

Future improvements:
- Add automatic price updates from CoinGecko API
- Support multiple cryptocurrencies
- Add webhook for real-time transaction detection
- Customer dashboard to re-download purchases
- Discount codes and promotions

## 📝 License

MIT License - Feel free to use and modify for your projects

## 🆘 Support

If you need help:
1. Check the error logs
2. Verify all environment variables are set
3. Test with a small ERG amount first
4. Contact support@agenticaihome.com

---

**Security Note**: Keep your wallet seed phrase and API keys secure. Never share them or commit them to version control.
